# Billiards 2D (Java + JavaFX + HTML)

Một game bida 2D đơn giản viết bằng Java/JavaFX, kèm một trang HTML giới thiệu.

## Yêu cầu
- JDK 17 trở lên (khuyến nghị 17)
- Internet (để Gradle tải JavaFX nếu cần)

## Chạy trên Windows (PowerShell)

Tại thư mục dự án (cùng cấp `build.gradle`):

```powershell
# Nếu có Gradle Wrapper (khuyến nghị):
./gradlew.bat run

# Nếu bạn đã cài Gradle trong PATH:
gradle run
```

Nếu gặp lỗi module JavaFX khi chạy IDE, đảm bảo cấu hình VM Options (nếu cần):

```
--module-path <path-to-javafx-sdk>/lib --add-modules javafx.controls,javafx.graphics
```

## Điều khiển
- Nhấn giữ chuột trái trên bi cái (bi trắng), kéo ngược để ngắm và tăng lực.
- Thả chuột để đánh.

## Cấu trúc dự án
- `src/main/java/biaa/BilliardsApp.java` – ứng dụng JavaFX, vẽ bàn, xử lý va chạm và input.
- `src/main/java/biaa/Ball.java` – định nghĩa bi (trạng thái, màu, vận tốc, ma sát).
- `src/main/java/biaa/Vector2.java` – tiện ích vector 2D.
- `web/index.html` – trang HTML giới thiệu & hướng dẫn nhanh.
- `build.gradle` / `settings.gradle` – cấu hình Gradle & JavaFX.

## Ghi chú
- Vật lý được đơn giản hóa (ma sát tuyến tính mỗi khung hình, va chạm đàn hồi gần đúng).
- Bạn có thể mở rộng: thêm lỗ, luật 8-ball/9-ball, UI điểm số, âm thanh.

## License
MIT
linkyt httpsyoutu.befgL42MxCi-o

