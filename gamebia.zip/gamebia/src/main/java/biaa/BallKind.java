package biaa;

public enum BallKind {
    CUE,
    EIGHT,
    SOLID,
    STRIPE
}


