package biaa;

import javafx.scene.paint.Color;

public class Ball {
    public final int id;
    public final double radius;
    public final Color color;
    public final BallKind kind;
    public Vector2 position;
    public Vector2 velocity;
    public boolean pocketed = false;

    public Ball(int id, BallKind kind, Vector2 position, double radius, Color color) {
        this.id = id;
        this.kind = kind;
        this.position = position;
        this.radius = radius;
        this.color = color;
        this.velocity = new Vector2(0, 0);
    }

    public void applyFriction(double friction) {
        velocity = velocity.multiply(friction);
        if (velocity.magnitude() < 1e-2) {
            velocity = new Vector2(0, 0);
        }
    }

    public boolean isMoving() {
        return !pocketed && (Math.abs(velocity.x) > 1e-3 || Math.abs(velocity.y) > 1e-3);
    }
}


