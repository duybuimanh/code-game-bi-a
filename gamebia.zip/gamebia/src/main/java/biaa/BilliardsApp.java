package biaa;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.Stop;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BilliardsApp extends Application {
    private static final double TABLE_WIDTH = 1000;
    private static final double TABLE_HEIGHT = 500;
    private static final double CUSHION = 30;
    private static final double BALL_RADIUS = 12;
    private static final double FRICTION = 0.992; // per frame
    private static final double POWER_SCALE = 0.12;
    private static final double POCKET_RADIUS = 22;
    private static final int PHYSICS_STEPS = 2; // sub-steps per frame for stability
    private static final double RESTITUTION = 0.92; // bounciness for ball-ball
    private static final double FRICTION_COEFF = 0.03; // tangential friction in collisions
    private static final double POSITION_CORRECT_PERCENT = 0.8; // Baumgarte percentage
    private static final double POSITION_SLop = 0.01; // small penetration allowed

    private final List<Ball> balls = new ArrayList<>();
    private Ball cueBall;
    private Ball eightBall;

    private Vector2 aimStart = null;
    private Vector2 aimCurrent = null;
    private boolean aiming = false;

    private final Vector2[] pockets = new Vector2[] {
            new Vector2(CUSHION, CUSHION),
            new Vector2(TABLE_WIDTH / 2.0, CUSHION),
            new Vector2(TABLE_WIDTH - CUSHION, CUSHION),
            new Vector2(CUSHION, TABLE_HEIGHT - CUSHION),
            new Vector2(TABLE_WIDTH / 2.0, TABLE_HEIGHT - CUSHION),
            new Vector2(TABLE_WIDTH - CUSHION, TABLE_HEIGHT - CUSHION)
    };

    private enum GameMode { TWO_PLAYERS, VS_AI }
    private GameMode gameMode = GameMode.TWO_PLAYERS;
    private final Player[] players = new Player[] { new Player("Người 1", false), new Player("Người 2", true) };
    private int currentPlayerIndex = 0;
    private boolean shotInProgress = false;
    private boolean breakShot = true;
    private final Random rng = new Random();
    private Label infoLabel;
    private Label turnLabel;

    // Settings state
    private boolean showAimGuide = true;
    private double userPowerScale = POWER_SCALE;
    private double userFriction = FRICTION;
    private Color feltColor = Color.web("#7ec8e3"); // light blue felt
    private boolean gameStarted = false;

    // UI nodes
    private VBox settingsPanel;
    private VBox startPanel;
    private double viewWidth = TABLE_WIDTH;
    private double viewHeight = TABLE_HEIGHT;

    // Shot tracking for rules
    private boolean firstContactRecorded = false;
    private Ball firstContactBall = null;
    private boolean anyPocketedThisShot = false;
    private int railsHitThisShot = 0;
    private boolean foulThisShot = false;
    private boolean ballInHand = false;

    @Override
    public void start(Stage stage) {
        Canvas canvas = new Canvas(TABLE_WIDTH, TABLE_HEIGHT);
        GraphicsContext g = canvas.getGraphicsContext2D();

        setupGame(GameMode.TWO_PLAYERS);
        setupInput(canvas);

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                updatePhysics();
                render(g);
                maybeAiPlay();
            }
        };
        timer.start();

        // UI controls
        Button twoBtn = new Button("2 Người chơi");
        Button aiBtn = new Button("Đấu máy");
        stylePrimary(twoBtn);
        stylePrimary(aiBtn);
        twoBtn.setOnAction(e -> { setupGame(GameMode.TWO_PLAYERS); gameStarted = true; startPanel.setVisible(false); });
        aiBtn.setOnAction(e -> { setupGame(GameMode.VS_AI); gameStarted = true; startPanel.setVisible(false); });
        HBox buttons = new HBox(8, twoBtn, aiBtn);
        buttons.setAlignment(Pos.CENTER_LEFT);
        turnLabel = new Label();
        infoLabel = new Label();
        infoLabel.setTextFill(Color.WHITE);
        turnLabel.setTextFill(Color.WHITE);
        HBox hud = new HBox(20, buttons, turnLabel, infoLabel);
        hud.setAlignment(Pos.CENTER_LEFT);
        hud.setMouseTransparent(true);

        // Settings panel
        settingsPanel = buildSettingsPanel();
        settingsPanel.setVisible(false);

        // Start panel (require mode selection)
        startPanel = buildStartPanel(twoBtn, aiBtn);

        VBox overlay = new VBox(8, hud, settingsPanel, startPanel);
        overlay.setAlignment(Pos.TOP_LEFT);
        overlay.setPickOnBounds(false);

        StackPane root = new StackPane(canvas, overlay);
        Scene scene = new Scene(root, TABLE_WIDTH, TABLE_HEIGHT);
        stage.setTitle("Billiards 2D - JavaFX");
        stage.setScene(scene);
        stage.setMaximized(true);
        // Resize canvas with scene
        scene.widthProperty().addListener((obs, o, w) -> { canvas.setWidth(w.doubleValue()); viewWidth = w.doubleValue(); });
        scene.heightProperty().addListener((obs, o, h) -> { canvas.setHeight(h.doubleValue()); viewHeight = h.doubleValue(); });
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.S) {
                settingsPanel.setVisible(!settingsPanel.isVisible());
            }
        });
        stage.show();
    }

    private void setupGame(GameMode mode) {
        this.gameMode = mode;
        balls.clear();
        // Reset players
        players[0] = new Player("Người 1", false);
        players[1] = new Player(mode == GameMode.VS_AI ? "Máy" : "Người 2", mode == GameMode.VS_AI);
        currentPlayerIndex = 0;
        breakShot = true;
        shotInProgress = false;

        // Cue ball
        cueBall = new Ball(0, BallKind.CUE, new Vector2(CUSHION + 200, TABLE_HEIGHT / 2), BALL_RADIUS, Color.WHITE);
        balls.add(cueBall);

        // Full rack: 15 object balls including 8-ball
        double startX = TABLE_WIDTH - CUSHION - 300;
        double startY = TABLE_HEIGHT / 2;
        int num = 0;
        int rows = 5; // 1..5 -> 15
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c <= r; c++) {
                int id = ++num;
                BallKind kind;
                if (id == 8) {
                    kind = BallKind.EIGHT;
                } else if (id >= 1 && id <= 7) {
                    kind = BallKind.SOLID;
                } else {
                    kind = BallKind.STRIPE;
                }
                Color color = kind == BallKind.EIGHT ? Color.BLACK : (kind == BallKind.SOLID ? Color.ORANGE : Color.LIGHTBLUE);
                double x = startX + r * (BALL_RADIUS * 2 + 1.2);
                double y = startY - r * BALL_RADIUS + c * (BALL_RADIUS * 2);
                Ball b = new Ball(id, kind, new Vector2(x, y), BALL_RADIUS, color);
                balls.add(b);
                if (kind == BallKind.EIGHT) eightBall = b;
            }
        }

        updateHud("Bắt đầu ván mới - " + (mode == GameMode.VS_AI ? "Đấu máy" : "2 người"));
    }

    private void setupInput(Canvas canvas) {
        canvas.setOnMousePressed(e -> {
            if (e.getButton() != MouseButton.PRIMARY) return;
            if (anyBallMoving()) return;
            if (!gameStarted) return;
            if (ballInHand && !currentPlayer().isAi) {
                // Place cue ball
                Vector2 pos = new Vector2(e.getX(), e.getY());
                if (canPlaceCueAt(pos)) {
                    cueBall.position = pos;
                    cueBall.pocketed = false;
                    cueBall.velocity = new Vector2(0, 0);
                    ballInHand = false;
                    updateHud("Đặt bi cái xong. Có thể đánh.");
                } else {
                    updateHud("Vị trí đặt không hợp lệ (trùng/ra ngoài).");
                }
                return;
            }
            if (currentPlayer().isAi) return;
            aiming = true;
            aimStart = new Vector2(cueBall.position.x, cueBall.position.y);
            aimCurrent = screenToWorld(e.getX(), e.getY());
        });
        canvas.setOnMouseDragged(e -> {
            if (!aiming) return;
            aimCurrent = screenToWorld(e.getX(), e.getY());
        });
        canvas.setOnMouseReleased(e -> {
            if (!aiming) return;
            aiming = false;
            aimCurrent = screenToWorld(e.getX(), e.getY());
            Vector2 delta = aimStart.subtract(aimCurrent);
            cueBall.velocity = new Vector2(delta.x * userPowerScale, delta.y * userPowerScale);
            shotInProgress = true;
            // Reset shot trackers
            firstContactRecorded = false;
            firstContactBall = null;
            anyPocketedThisShot = false;
            railsHitThisShot = 0;
            foulThisShot = false;
        });
    }

    private boolean anyBallMoving() {
        for (Ball b : balls) if (b.isMoving()) return true;
        return false;
    }

    private void updatePhysics() {
        // Sub-stepped integration to improve stability
        double substepFriction = Math.pow(userFriction, 1.0 / PHYSICS_STEPS);
        for (int step = 0; step < PHYSICS_STEPS; step++) {
            for (Ball b : balls) {
                if (b.pocketed) continue;
                b.position = b.position.add(b.velocity.multiply(1.0 / PHYSICS_STEPS));
                b.applyFriction(substepFriction);
                handleCushionCollision(b);
                handlePocket(b);
            }
            // A few iterative passes each substep
            for (int pass = 0; pass < 2; pass++) {
                int n = balls.size();
                for (int i = 0; i < n; i++) {
                    for (int j = i + 1; j < n; j++) {
                        resolveBallCollision(balls.get(i), balls.get(j));
                    }
                }
            }
        }

        // End of shot handling: when all stop after a shot
        if (shotInProgress && !anyBallMoving()) {
            evaluateShotAndSwitchTurns();
            shotInProgress = false;
        }
    }

    private void handleCushionCollision(Ball b) {
        double left = CUSHION + b.radius;
        double right = TABLE_WIDTH - CUSHION - b.radius;
        double top = CUSHION + b.radius;
        double bottom = TABLE_HEIGHT - CUSHION - b.radius;

        if (b.position.x < left) {
            b.position = new Vector2(left, b.position.y);
            b.velocity = new Vector2(-b.velocity.x, b.velocity.y);
            if (shotInProgress && firstContactRecorded) railsHitThisShot++;
        } else if (b.position.x > right) {
            b.position = new Vector2(right, b.position.y);
            b.velocity = new Vector2(-b.velocity.x, b.velocity.y);
            if (shotInProgress && firstContactRecorded) railsHitThisShot++;
        }
        if (b.position.y < top) {
            b.position = new Vector2(b.position.x, top);
            b.velocity = new Vector2(b.velocity.x, -b.velocity.y);
            if (shotInProgress && firstContactRecorded) railsHitThisShot++;
        } else if (b.position.y > bottom) {
            b.position = new Vector2(b.position.x, bottom);
            b.velocity = new Vector2(b.velocity.x, -b.velocity.y);
            if (shotInProgress && firstContactRecorded) railsHitThisShot++;
        }
    }

    private void handlePocket(Ball b) {
        if (b.pocketed) return;
        for (Vector2 p : pockets) {
            if (b.position.distanceTo(p) <= POCKET_RADIUS) {
                b.pocketed = true;
                b.velocity = new Vector2(0, 0);
                if (shotInProgress) anyPocketedThisShot = true;
                if (b.kind == BallKind.CUE) {
                    // Scratch: mark foul, give ball-in-hand next turn
                    foulThisShot = true;
                }
                break;
            }
        }
    }

    private void resolveBallCollision(Ball a, Ball b) {
        if (a.pocketed || b.pocketed) return;
        Vector2 delta = b.position.subtract(a.position);
        double dist = delta.magnitude();
        double minDist = a.radius + b.radius;
        if (dist == 0 || dist > minDist) return;

        // Normal
        Vector2 normal = delta.normalize();
        if (dist == 0) normal = new Vector2(1, 0);

        // Position correction (Baumgarte) to avoid persistent overlap
        double penetration = minDist - dist;
        double correctionMag = Math.max(penetration - POSITION_SLop, 0.0) * (POSITION_CORRECT_PERCENT / 2.0);
        Vector2 correction = normal.multiply(correctionMag);
        a.position = a.position.subtract(correction);
        b.position = b.position.add(correction);

        // Detect first contact with cue ball for rules
        if (!firstContactRecorded && (a == cueBall || b == cueBall)) {
            Ball other = (a == cueBall) ? b : a;
            if (other.kind != BallKind.CUE) {
                firstContactRecorded = true;
                firstContactBall = other;
            }
        }

        // Relative velocity
        Vector2 rv = b.velocity.subtract(a.velocity);
        double velAlongNormal = rv.dot(normal);
        if (velAlongNormal > 0) return; // moving apart

        // Impulse scalar (equal mass -> invMassSum = 2)
        double j = -(1.0 + RESTITUTION) * velAlongNormal / 2.0;
        Vector2 impulse = normal.multiply(j);
        a.velocity = a.velocity.subtract(impulse);
        b.velocity = b.velocity.add(impulse);

        // Tangential friction to make more natural roll/slide
        rv = b.velocity.subtract(a.velocity);
        Vector2 tangent = rv.subtract(normal.multiply(rv.dot(normal)));
        double tMag = tangent.magnitude();
        if (tMag > 1e-8) {
            tangent = tangent.multiply(1.0 / tMag);
            double jt = -rv.dot(tangent) / 2.0;
            // Coulomb friction clamp
            double maxFriction = j * FRICTION_COEFF;
            if (jt > maxFriction) jt = maxFriction;
            if (jt < -maxFriction) jt = -maxFriction;
            Vector2 frictionImp = tangent.multiply(jt);
            a.velocity = a.velocity.subtract(frictionImp);
            b.velocity = b.velocity.add(frictionImp);
        }
    }

    private void render(GraphicsContext g) {
        // Table background (scaled)
        g.setFill(feltColor);
        g.fillRect(0, 0, viewWidth, viewHeight);
        // Subtle vignette to make it pop
        g.setFill(Color.color(0,0,0,0.15));
        g.fillRect(0, 0, viewWidth, 30);
        g.fillRect(0, viewHeight - 30, viewWidth, 30);
        g.fillRect(0, 0, 30, viewHeight);
        g.fillRect(viewWidth - 30, 0, 30, viewHeight);
        g.save();
        scaleToView(g);
        // Felt gradient for depth
        RadialGradient feltGrad = new RadialGradient(0, 0, TABLE_WIDTH/2.0, TABLE_HEIGHT/2.0, Math.max(TABLE_WIDTH, TABLE_HEIGHT)/2.0,
                false, CycleMethod.NO_CYCLE,
                new Stop(0, feltColor.brighter()),
                new Stop(1, feltColor.darker()));
        g.setFill(feltGrad);
        g.fillRect(0, 0, TABLE_WIDTH, TABLE_HEIGHT);

        // Wooden cushions and frame
        Color wood = Color.web("#8b5a2b");
        Color woodDark = wood.darker();
        g.setFill(wood);
        g.fillRect(0, 0, TABLE_WIDTH, CUSHION);
        g.fillRect(0, TABLE_HEIGHT - CUSHION, TABLE_WIDTH, CUSHION);
        g.fillRect(0, 0, CUSHION, TABLE_HEIGHT);
        g.fillRect(TABLE_WIDTH - CUSHION, 0, CUSHION, TABLE_HEIGHT);
        g.setStroke(woodDark);
        g.setLineWidth(4 / getScaleX());
        g.strokeRect(2, 2, TABLE_WIDTH - 4, TABLE_HEIGHT - 4);

        // Pockets
        g.setFill(Color.web("#101010"));
        for (Vector2 p : pockets) {
            g.fillOval(p.x - POCKET_RADIUS, p.y - POCKET_RADIUS, POCKET_RADIUS * 2, POCKET_RADIUS * 2);
        }
        g.restore();

        // Guide/aim line while aiming
        if (showAimGuide && aiming && aimStart != null && aimCurrent != null) {
            g.save();
            scaleToView(g);
            // Base aim line (player-specific color)
            Color[] guide = currentPlayerGuideColors();
            g.setStroke(guide[0]);
            g.setLineWidth(2 / getScaleX());
            g.strokeLine(aimStart.x, aimStart.y, aimCurrent.x, aimCurrent.y);

            // Advanced guide: cue -> first target ball -> nearest pocket
            drawAdvancedAimGuide(g, guide);

            g.restore();
            g.setFill(Color.color(1, 1, 1, 0.9));
            g.fillText("Kéo ngược để tăng lực, thả để đánh", toScreenX(aimStart.x) + 12, toScreenY(aimStart.y) - 12);
        }

        // Balls (scaled)
        g.save();
        scaleToView(g);
        for (Ball b : balls) {
            if (b.pocketed) continue;
            g.setFill(Color.color(0,0,0,0.25));
            g.fillOval(b.position.x - b.radius + 2, b.position.y - b.radius + 3, b.radius * 2, b.radius * 2);
            g.setFill(b.color);
            g.fillOval(b.position.x - b.radius, b.position.y - b.radius, b.radius * 2, b.radius * 2);
            g.setStroke(Color.BLACK);
            g.setLineWidth(1 / getScaleX());
            g.strokeOval(b.position.x - b.radius, b.position.y - b.radius, b.radius * 2, b.radius * 2);

            // Draw ball number (centered)
            if (b.id > 0) {
                g.setTextAlign(TextAlignment.CENTER);
                g.setTextBaseline(VPos.CENTER);
                g.setFont(new Font(Math.max(10, b.radius * 1.4)));
                Color numColor = (b.kind == BallKind.EIGHT || b.color.equals(Color.BLACK)) ? Color.WHITE : Color.BLACK;
                if (b.kind == BallKind.CUE) numColor = Color.BLACK;
                g.setFill(numColor);
                g.fillText(String.valueOf(b.id), b.position.x, b.position.y);
            }
        }
        g.restore();

        // HUD text
        g.setFill(Color.WHITE);
        g.fillText("Nhấn giữ chuột trái trên bi cái để ngắm. Kéo ngược để chỉnh lực, thả để đánh.", 20, 22);
    }

    public static void main(String[] args) {
        launch(args);
    }

    private Player currentPlayer() { return players[currentPlayerIndex]; }

    private void evaluateShotAndSwitchTurns() {
        boolean cuePocketed = cueBall.pocketed;
        List<Ball> pocketedThisShot = new ArrayList<>();
        for (Ball b : balls) {
            if (b == cueBall) continue;
            if (b.pocketed) pocketedThisShot.add(b);
        }

        Player cur = currentPlayer();

        // Determine fouls
        boolean foul = foulThisShot;
        // First-hit rule
        if (!foul) {
            if (firstContactBall == null) {
                // no contact
                foul = true;
            } else {
                if (players[0].assignedKind != null && players[1].assignedKind != null) {
                    // must hit own group first
                    if (!(firstContactBall.kind == cur.assignedKind || firstContactBall.kind == BallKind.EIGHT && cur.pocketedOwn >= 7)) {
                        foul = true;
                    }
                }
            }
        }
        // Rail after contact unless a ball is pocketed
        if (!foul && !anyPocketedThisShot && railsHitThisShot == 0 && firstContactBall != null) {
            foul = true;
        }
        // Break rule: must pocket a ball or drive 4 balls to rails
        if (breakShot && !anyPocketedThisShot && railsHitThisShot < 4) {
            foul = true;
        }

        // Assign kinds when first legal pocket happens (no foul on that shot)
        boolean scoredOwn = false;
        if (!foul) {
            for (Ball b : pocketedThisShot) {
                if (b.kind == BallKind.SOLID || b.kind == BallKind.STRIPE) {
                    if (players[0].assignedKind == null && players[1].assignedKind == null) {
                        cur.assignedKind = b.kind;
                        players[1 - currentPlayerIndex].assignedKind = (b.kind == BallKind.SOLID ? BallKind.STRIPE : BallKind.SOLID);
                        updateHud(cur.name + " nhận nhóm: " + (cur.assignedKind == BallKind.SOLID ? "Bi liền" : "Bi sọc"));
                    }
                    if (cur.assignedKind == b.kind) {
                        cur.pocketedOwn++;
                        scoredOwn = true;
                    }
                }
            }
        }

        boolean eightPocketed = pocketedThisShot.stream().anyMatch(b -> b.kind == BallKind.EIGHT);
        if (eightPocketed) {
            boolean curCleared = cur.assignedKind != null && cur.pocketedOwn >= 7;
            if (!foul && curCleared) {
                updateHud(cur.name + " thắng (bi 8 hợp lệ)");
            } else {
                updateHud(cur.name + " thua (bi 8 không hợp lệ)");
            }
            setupGame(gameMode);
            return;
        }

        // Cue ball scratch -> ball in hand next player
        if (cuePocketed) {
            // keep pocketed state; next player will place
        }

        if (foul) {
            // switch turn, give ball-in-hand
            currentPlayerIndex = 1 - currentPlayerIndex;
            ballInHand = true;
            // Temporarily move cue off-table to indicate needs placing
            cueBall.pocketed = true;
            updateHud("Lỗi: đối thủ được đặt bi cái (ball-in-hand)");
        } else {
            if (scoredOwn) {
                updateHud(cur.name + " được đánh tiếp");
            } else {
                currentPlayerIndex = 1 - currentPlayerIndex;
                updateHud("Đến lượt: " + currentPlayer().name);
            }
        }
        breakShot = false;
    }

    private void maybeAiPlay() {
        if (anyBallMoving() || shotInProgress) return;
        if (!gameStarted) return;
        Player cur = currentPlayer();
        if (!cur.isAi) return;
        if (ballInHand) {
            // Place cue ball automatically to a safe spot on the left
            Vector2 pos = new Vector2(CUSHION + 200, TABLE_HEIGHT / 2);
            // Nudge until no overlap
            double angle = 0;
            while (!canPlaceCueAt(pos) && angle < Math.PI * 2) {
                pos = new Vector2(pos.x + Math.cos(angle) * 5, pos.y + Math.sin(angle) * 5);
                angle += 0.2;
            }
            cueBall.position = pos;
            cueBall.pocketed = false;
            ballInHand = false;
        }
        // Simple AI: aim at nearest target ball
        Ball target = chooseAiTarget(cur);
        if (target == null) {
            // Fallback: nudge forward
            target = eightBall;
        }
        Vector2 toTarget = target.position.subtract(cueBall.position).normalize();
        double power = 90 + rng.nextDouble() * 70; // tweakable power
        cueBall.velocity = toTarget.multiply(userPowerScale * power);
        shotInProgress = true;
        // Reset shot trackers for AI as well
        firstContactRecorded = false;
        firstContactBall = null;
        anyPocketedThisShot = false;
        railsHitThisShot = 0;
        foulThisShot = false;
    }

    private Ball chooseAiTarget(Player cur) {
        BallKind desired = cur.assignedKind;
        double bestDist = Double.MAX_VALUE;
        Ball best = null;
        for (Ball b : balls) {
            if (b.pocketed || b == cueBall || b.kind == BallKind.EIGHT) continue;
            if (desired != null && b.kind != desired) continue;
            double d = cueBall.position.distanceTo(b.position);
            if (d < bestDist) { bestDist = d; best = b; }
        }
        return best;
    }

    private void updateHud(String message) {
        if (turnLabel != null) {
            String kindA = players[0].assignedKind == null ? "?" : (players[0].assignedKind == BallKind.SOLID ? "Liền" : "Sọc");
            String kindB = players[1].assignedKind == null ? "?" : (players[1].assignedKind == BallKind.SOLID ? "Liền" : "Sọc");
            turnLabel.setText("Lượt: " + currentPlayer().name + "  |  P1:" + kindA + "=" + players[0].pocketedOwn + "  P2:" + kindB + "=" + players[1].pocketedOwn);
        }
        if (infoLabel != null) infoLabel.setText(message);
    }

    private boolean canPlaceCueAt(Vector2 pos) {
        double left = CUSHION + cueBall.radius;
        double right = TABLE_WIDTH - CUSHION - cueBall.radius;
        double top = CUSHION + cueBall.radius;
        double bottom = TABLE_HEIGHT - CUSHION - cueBall.radius;
        if (pos.x < left || pos.x > right || pos.y < top || pos.y > bottom) return false;
        for (Ball b : balls) {
            if (b == cueBall || b.pocketed) continue;
            if (pos.distanceTo(b.position) < cueBall.radius + b.radius + 1) return false;
        }
        return true;
    }

    private VBox buildSettingsPanel() {
        Label title = new Label("Cài đặt (nhấn S để ẩn/hiện)");
        title.setTextFill(Color.WHITE);

        CheckBox aim = new CheckBox("Hiển thị đường ngắm");
        aim.setSelected(showAimGuide);
        aim.setTextFill(Color.WHITE);
        aim.selectedProperty().addListener((obs, o, v) -> showAimGuide = v);

        Label powerLbl = new Label("Lực đánh");
        powerLbl.setTextFill(Color.WHITE);
        Slider power = new Slider(0.05, 0.25, userPowerScale);
        power.valueProperty().addListener((obs, o, v) -> userPowerScale = v.doubleValue());

        Label fricLbl = new Label("Ma sát");
        fricLbl.setTextFill(Color.WHITE);
        Slider fric = new Slider(0.980, 0.998, userFriction);
        fric.setBlockIncrement(0.001);
        fric.valueProperty().addListener((obs, o, v) -> userFriction = v.doubleValue());

        VBox panel = new VBox(6, title, aim, powerLbl, power, fricLbl, fric);
        panel.setStyle("-fx-background-color: rgba(10,10,20,0.7); -fx-padding: 10; -fx-background-radius: 10; -fx-border-color: #1f2b44; -fx-border-radius: 10;");
        panel.setAlignment(Pos.TOP_LEFT);
        return panel;
    }

    private VBox buildStartPanel(Button twoBtn, Button aiBtn) {
        Label t = new Label("Chọn chế độ chơi để bắt đầu");
        t.setTextFill(Color.WHITE);
        HBox row = new HBox(10, twoBtn, aiBtn);
        row.setAlignment(Pos.CENTER);
        VBox panel = new VBox(10, t, row);
        panel.setStyle("-fx-background-color: rgba(0,0,0,0.55); -fx-padding: 16; -fx-background-radius: 12;");
        panel.setAlignment(Pos.CENTER);
        panel.setMouseTransparent(false);
        return panel;
    }

    private void stylePrimary(Button b) {
        b.setStyle("-fx-background-color:#2563eb; -fx-text-fill:white; -fx-padding:8 12; -fx-background-radius:8;");
    }

    // ===== Rendering helpers for scaling =====
    private double getScaleX() { return viewWidth / TABLE_WIDTH; }
    private double getScaleY() { return viewHeight / TABLE_HEIGHT; }
    private void scaleToView(GraphicsContext g) { g.scale(getScaleX(), getScaleY()); }
    private Vector2 screenToWorld(double sx, double sy) { return new Vector2(sx / getScaleX(), sy / getScaleY()); }
    private double toScreenX(double wx) { return wx * getScaleX(); }
    private double toScreenY(double wy) { return wy * getScaleY(); }

    // ===== Advanced aim guide =====
    private void drawAdvancedAimGuide(GraphicsContext g, Color[] guideColors) {
        Vector2 dir = aimStart.subtract(aimCurrent).normalize();
        if (dir.magnitude() < 1e-6) return;
        Ball hit = null;
        Vector2 hitPoint = null;
        double bestT = Double.MAX_VALUE;
        for (Ball b : balls) {
            if (b == cueBall || b.pocketed) continue;
            Vector2 hp = rayCircleIntersect(cueBall.position, dir, b.position, cueBall.radius + b.radius);
            if (hp != null) {
                double t = hp.subtract(cueBall.position).magnitude();
                if (t < bestT) { bestT = t; hit = b; hitPoint = hp; }
            }
        }
        if (hit != null && hitPoint != null) {
            g.setStroke(guideColors[0]);
            g.setLineWidth(2 / getScaleX());
            g.strokeLine(aimStart.x, aimStart.y, hitPoint.x, hitPoint.y);

            // From target ball to nearest pocket
            Vector2 pocket = nearestPocket(hit.position);
            if (pocket != null) {
                g.setStroke(guideColors[1]);
                g.setLineDashes(8 / getScaleX());
                g.strokeLine(hit.position.x, hit.position.y, pocket.x, pocket.y);
                g.setLineDashes(null);
            }
        } else {
            // fallback long line to cushion
            Vector2 end = extendToCushion(cueBall.position, dir);
            g.setStroke(guideColors[0]);
            g.setLineWidth(2 / getScaleX());
            g.strokeLine(aimStart.x, aimStart.y, end.x, end.y);
        }
    }

    private Color[] currentPlayerGuideColors() {
        // Player 1: cyan + green, Player 2: orange + magenta
        if (currentPlayerIndex == 0) {
            return new Color[] { Color.color(0.2, 0.95, 1.0, 0.9), Color.color(0.4, 1.0, 0.6, 0.9) };
        } else {
            return new Color[] { Color.color(1.0, 0.6, 0.2, 0.9), Color.color(1.0, 0.4, 0.9, 0.9) };
        }
    }

    private Vector2 nearestPocket(Vector2 from) {
        double best = Double.MAX_VALUE;
        Vector2 chosen = null;
        for (Vector2 p : pockets) {
            double d = from.distanceTo(p);
            if (d < best) { best = d; chosen = p; }
        }
        return chosen;
    }

    private Vector2 extendToCushion(Vector2 origin, Vector2 dir) {
        // simple extend until hits table bounds minus cushion
        double t = 1e6;
        double left = CUSHION; double right = TABLE_WIDTH - CUSHION;
        double top = CUSHION; double bottom = TABLE_HEIGHT - CUSHION;
        if (Math.abs(dir.x) > 1e-6) {
            double tx1 = (left - origin.x) / dir.x;
            double tx2 = (right - origin.x) / dir.x;
            if (tx1 > 0) t = Math.min(t, tx1);
            if (tx2 > 0) t = Math.min(t, tx2);
        }
        if (Math.abs(dir.y) > 1e-6) {
            double ty1 = (top - origin.y) / dir.y;
            double ty2 = (bottom - origin.y) / dir.y;
            if (ty1 > 0) t = Math.min(t, ty1);
            if (ty2 > 0) t = Math.min(t, ty2);
        }
        return origin.add(dir.multiply(t));
    }

    private Vector2 rayCircleIntersect(Vector2 o, Vector2 d, Vector2 c, double r) {
        // Solve |o + d*t - c|^2 = r^2 for t>0, d normalized
        double ox = o.x - c.x, oy = o.y - c.y;
        double b = 2 * (d.x * ox + d.y * oy);
        double cc = ox * ox + oy * oy - r * r;
        double disc = b * b - 4 * cc;
        if (disc < 0) return null;
        double sqrt = Math.sqrt(disc);
        double t1 = (-b - sqrt) / 2.0;
        double t2 = (-b + sqrt) / 2.0;
        double t = Double.MAX_VALUE;
        if (t1 > 0) t = Math.min(t, t1);
        if (t2 > 0) t = Math.min(t, t2);
        if (t == Double.MAX_VALUE) return null;
        return new Vector2(o.x + d.x * t, o.y + d.y * t);
    }
}


