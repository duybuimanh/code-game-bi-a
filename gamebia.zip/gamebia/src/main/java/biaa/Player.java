package biaa;

public final class Player {
    public final String name;
    public final boolean isAi;
    public BallKind assignedKind; // SOLID or STRIPE once determined
    public int pocketedOwn;

    public Player(String name, boolean isAi) {
        this.name = name;
        this.isAi = isAi;
        this.assignedKind = null;
        this.pocketedOwn = 0;
    }
}


